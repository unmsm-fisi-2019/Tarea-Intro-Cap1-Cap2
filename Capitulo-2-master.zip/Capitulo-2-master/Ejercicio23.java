
package capitulo2;
public class Ejercicio23 {
    
}
