package capitulo1;
public class Ejercicio7 {
        public static void main(String[] args) {
        System.out.print("La primera aproximacion es: ");
        System.out.println(4*(1.0-(1.0/3)+(1.0/5)-(1.0/7)-(1.0/11)));
        System.out.print("La segunda aproximacion es: ");
        System.out.println(4*(1.0-(1.0/3)+(1.0/5)-(1.0/7)-(1.0/11)+(1.0/13)));
    }
}
