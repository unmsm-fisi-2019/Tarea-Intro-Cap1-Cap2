package capitulo1;
public class Ejercicio8 {
     public static void main(String[] args) {
		System.out.println("Perimetro = ");
		System.out.println(2 * 5.5 * 3.14159);
		System.out.println("Area = ");
		System.out.println(5.5 * 5.5 * 3.14159);
	} 
}
