package capitulo1;
public class Ejercicio5 {
   public static void main(String[] arg) {

        System.out.println("(9.5 * 4.5 - 2.5 * 3) / (45.5 - 3.5) = "+(9.5 * 4.5 - 2.5 * 3) / (45.5 - 3.5));
    }
    
}
