package capitulo1;
public class Ejercicio9 {
        public static void main(String[] args) {
	System.out.println("Area = ");
	System.out.println(4.5 * 7.9);
	System.out.println("Perimetro = ");
	System.out.println((4.5 + 7.9) * 2);
	}
}
