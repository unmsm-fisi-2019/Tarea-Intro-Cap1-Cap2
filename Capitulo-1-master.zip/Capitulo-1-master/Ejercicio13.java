package capitulo1;
public class Ejercicio13 {
    public static void main(String[] strings) {
    double X=(44.5*55-50.2*5.9)/(3.4*55-50.2*2.1);
    double Y=(3.4*5.9-44.5*2.1)/(3.4*55-50.2*2.1);
    System.out.println("X = "+X+" Y = "+Y);
     }
}
