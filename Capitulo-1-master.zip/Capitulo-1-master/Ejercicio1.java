package capitulo1;
public class Ejercicio1 {
    public static void main(String[] args) {
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Computer Science");
		System.out.println("Programming is fun");
	}
    
}
